const els = document.querySelectorAll('.reveal');
if ('IntersectionObserver' in window) {
  const io = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('in');
        io.unobserve(entry.target);
      }
    });
  }, { threshold: 0.12 });
  els.forEach(el => io.observe(el));
} else {
  els.forEach(el => el.classList.add('in'));
}

const form = document.querySelector('[data-scope-form]');
if (form) {
  form.addEventListener('submit', (event) => {
    event.preventDefault();
    const data = new FormData(form);
    const lines = [
      'New Daftar Advisory inquiry',
      '',
      `Name: ${data.get('name') || ''}`,
      `Email: ${data.get('email') || ''}`,
      `Company: ${data.get('company') || ''}`,
      `Service: ${data.get('service') || ''}`,
      `Timeline: ${data.get('timeline') || ''}`,
      '',
      'Message:',
      data.get('message') || ''
    ];
    const subject = encodeURIComponent('Daftar Advisory inquiry');
    const body = encodeURIComponent(lines.join('\n'));
    window.location.href = `mailto:ahmad@daftaradvisory.com?subject=${subject}&body=${body}`;
  });
}
