# Daftar Advisory — consolidated final website

This folder is the recommended final version.

## What changed

- Split the website into clear pages instead of one long scroll.
- Kept the main sections simple: `Services`, `About`, and `How it works`.
- Added a dedicated `Scope a call` page with a service dropdown and inquiry form.
- Added footer/end pages for `Ethics & values`, `Letter from founder`, and `Articles`.
- Rewrote the copy in shorter, simpler language.
- Kept the brand restrained: warm paper background, ink text, rust accent, rules instead of heavy visuals.
- Added light scroll-reveal animation with reduced-motion support.

## Page order

1. `index.html` — short homepage / page 1
2. `services.html` — services
3. `about.html` — about the practice
4. `how-it-works.html` — process
5. `scope-a-call.html` — dropdown + inquiry form
6. `ethics-values.html` — values and professional boundaries
7. `founder-letter.html` — founder note
8. `articles.html` — article index

## Form note

The form currently opens the visitor's email app and prepares a message to `ahmad@daftaradvisory.com`.
For production, connect the form to Netlify Forms, Formspree, HubSpot, Airtable, or the site's CRM.

## Do not upload

Do not upload the `_ds/fonts` folders from the older archives unless you have checked licensing and deployment needs.
This final package intentionally uses safe system fonts and does not include font files.
