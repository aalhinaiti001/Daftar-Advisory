# File organisation recommendation

## Keep as source archive

- `Daftar Advisory.zip` — original full archive with deployed pages, scoping intake, areas, and capability pages.
- `Homepage enhancement and animations.zip` — strongest visual/copy base. This is the version used as the main reference for the final site.
- `Daftar Advisory-Enhance attached design.zip` — useful reference for cleaner portfolio-style sections, but thinner than the homepage version.

## Delete or move to archive

These are exact duplicates based on SHA-256 checksum comparison:

- `Homepage enhancement and animations - Copy.zip`
- `Daftar Advisory-Enhance attached design - Copy.zip`

## Recommended working folders

```text
Daftar-Advisory/
  final-site/              # clean production candidate
  source-archive/          # original ZIPs only, not uploaded to production
  notes/                   # review notes, future copy changes, legal review notes
```

## Production candidate

Use `final-site/` as the clean handoff folder.
It contains only the pages, CSS, JavaScript, and image asset needed for the simplified version.
