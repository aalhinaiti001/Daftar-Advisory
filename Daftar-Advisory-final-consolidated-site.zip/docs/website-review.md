# Website review and improvement notes

## Recommended base

Use the `Homepage enhancement and animations` version as the creative base. It has the strongest homepage structure, clearer service language, better scoping form direction, and stronger visual rhythm.

Use the original `Daftar Advisory.zip` as the reference archive because it contains more page types and source material.

## Main issue fixed

The previous versions were too close to one long editorial scroll. The final version turns the site into a page journey:

Home → Services → About → How it works → Scope a call → Ethics & values → Letter from founder → Articles

This gives each visitor a clear next step and avoids forcing them through the full site.

## Further improvements to consider

1. Connect the inquiry form to a real backend or CRM.
2. Add thank-you page after form submission.
3. Add calendar booking only after the service dropdown is completed, so calls are better qualified.
4. Build full article pages only for finished articles; avoid empty “read more” links.
5. Add a simple Arabic version once the English structure is approved.
6. Add professional boundary language to proposals as well as the website.
7. Consider one short proof section with anonymised outcomes, but keep it concise.
8. Avoid stock photos, icons, gradients, and heavy animations. The current brand works best with type, rules, and whitespace.

## Copy direction

Use simple words. Avoid corporate phrases such as “unlock”, “empower”, “best-in-class”, “synergy”, and “innovative”. The strongest tone is direct and calm.
